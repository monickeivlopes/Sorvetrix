# Sorvetrix
Projeto Interdisciplinar que abrange as matérias:
- Projeto de Interface do Usúario
- Programação Orientada a Serviços
- Projeto de Desenvolvimento de Sistemas para Internet

# Proposta
Sistema de gerenciamento para uma sorveteria

# Desenvolvedores
- Eunice Cristina 
- Gabriely Medeiros 
- Lívia Vitória
- Monicke Lopes
- Wesley Darlly
