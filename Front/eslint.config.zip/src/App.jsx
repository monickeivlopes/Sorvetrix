import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./componentes/login";
import Register from "./componentes/register";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </Router>
  );
}

export default App;
