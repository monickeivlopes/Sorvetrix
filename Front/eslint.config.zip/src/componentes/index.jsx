import { useState } from "react";
import "./index.css"
export default function Index(){
    return (
        <>
        <body>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></link>
        <div className="login-card">
      <div className="choco-top"></div>

      {/* Granulados */}
      <div className="sprinkle blue" style={{ top: "15px", left: "40px" }}></div>
      <div className="sprinkle yellow" style={{ top: "25px", left: "90px" }}></div>
      <div className="sprinkle pink" style={{ top: "18px", left: "200px" }}></div>
      <div className="sprinkle blue" style={{ top: "28px", left: "280px" }}></div>
      <div className="sprinkle yellow" style={{ top: "10px", left: "330px" }}></div>

      <h2 className="brand">Sorvetrix</h2>

      <form>
        <div className="mb-3">
          <input type="email" className="form-control" placeholder="E-mail" required />
        </div>
        <div className="mb-3">
          <input type="password" className="form-control" placeholder="Senha" required />
        </div>
        <button type="submit" className="btn-login">Entrar</button>
      </form>

      <div className="mt-3">
        <a href="#" className="text-muted">Esqueci minha senha</a>
      </div>
      <div className="footer-text">
        Feito com carinho e açúcar ♡
      </div>
    </div>
        </body>
        </>
    )
}