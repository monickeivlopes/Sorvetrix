import '../style.css';
import Header from './header';

export default function Register() {
  
  return (
    <>
    <Header/>
    <section id="register" class="screen">
      <div class="drip"></div>
      <div class="grid">
        <div class="card" style="padding:26px">
          <h2 style="margin:0 0 10px 0;color:var(--brown)">Cadastrar Usuário</h2>
          <p style="color:rgba(107,63,63,0.7)">Adicione funcionários e defina permissões.</p>

          <div style="margin-top:12px">
            <label>Nome</label>
            <input placeholder="Maria da Silva" />
            <label style="margin-top:8px">E-mail</label>
            <input placeholder="maria@exemplo.com" />
            <label style="margin-top:8px">Senha</label>
            <input type="password" placeholder="••••••" />
            <label style="margin-top:8px">Cargo</label>
            <select>
              <option>Atendente</option>
              <option>Administrador</option>
              <option>Gerente</option>
            </select>

            <div style="margin-top:14px;display:flex;gap:10px">
              <button class="btn">Cadastrar com carinho 🍦</button>
              <button class="ghost" onclick="switchTo('login')">Voltar</button>
            </div>
          </div>
        </div>

        <div class="preview card">
          <div style="font-size:18px;font-weight:800;color:var(--pink-strong)">Preview da Marca</div>
          <div style="display:flex;gap:10px;align-items:center;margin-top:10px">
            <div style="width:72px;height:72px;border-radius:12px;background:linear-gradient(180deg,var(--pink),var(--pink-strong));display:flex;align-items:center;justify-content:center;color:white;font-weight:900">S</div>
            <div>
              <div style="font-weight:700">Sorvetrix - Filial: Central</div>
              <div style="font-size:13px;color:rgba(107,63,63,0.6)">Rua das Flores, 123 — Tel (84) 9xxxx-xxxx</div>
            </div>
          </div>

          <div style="margin-top:18px;width:100%">
            <div style="display:flex;gap:8px">
              <div class="flavor-card" style="flex:1">
                <div class="flavor-img">🍓</div>
                <div style="margin-top:8px">Morango</div>
              </div>
              <div class="flavor-card" style="flex:1">
                <div class="flavor-img">🍫</div>
                <div style="margin-top:8px">Chocolate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    </>
  );
}
